
package com.mycompany.tugas_queue;

/**
 *
 * @author Dilah_15
 */
public class TugasQueue {

    public static void main(String[] args) {
        Program A = new Program("Fadilah", "Nurul", 270504);
        Program AB = new Program("Nurul", "Huda", 460217);
        Program ABC = new Program("Fadil", "Fadilah", 3322);
        Program ABCD = new Program("Nurul", "Hidayat", 050527);
        Program ABCDE = new Program("Nurul", "Fadilah", 240904);

        QueueArray queue = new QueueArray(10);
        queue.add(A);
        queue.add(AB);
        queue.add(ABC);
        queue.add(ABCD);
        queue.add(ABCDE);

        System.out.println("Add to Queue \n");
        queue.printQueue();

        queue.remove();
        queue.remove();
        System.out.println("Remove 2 Data from Queue \n");
        queue.printQueue();

        System.out.println("Peek Data From Queue \n");
        System.out.println(queue.peek());
        queue.remove();
        queue.remove();
        queue.remove();
        //queue.remove();

        queue.add(ABCD);

        System.out.println("Print Queue \n");
        queue.printQueue();
    }
}